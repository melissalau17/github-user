package com.dicoding.githubuser.data.remote.response

import com.dicoding.githubuser.model.User

data class UserResponse(
	val item: ArrayList<User>
)
